import React from 'react';

import Counter from './components/Counter-Styled/CounterStyled';
// import CounterCSSModule from './components/Counter-CSSModule/Counter';

import './App.css';

function App() {
  return (
    <div>
      <Counter />
      <hr/>
      {/* <CounterCSSModule/> */}
    </div>
  );
}

export default App;
