import React, { Component, ChangeEvent } from 'react';

import './App.css';
import { Dropdown } from './Dropdown';

interface AppState {
  count: number;
  text: string;
}

class App extends Component<any, AppState> {
  constructor(props: any) {
    super(props);

    this.state = { count: 0, text: '' };
    // this.handleClick = this.handleClick.bind(this);
  }

  incrementState = () => {
    // recommend
    this.setState((prevState) => ({ count: prevState.count + 1 }));
  };

  handleClick = () => {
    this.setState((prevState) => {
      console.log('inside1=', prevState.count);

      return { count: prevState.count + 1 }; //{ count: 1 }
    });
    this.setState((prevState) => {
      console.log('inside2=', prevState.count);

      return { count: prevState.count + 1 }; //  { count : 2 }
    });
    this.setState((prevState) => {
      console.log('inside3=', prevState.count);

      return { count: prevState.count + 1 }; // { count: 3 }
    });

    console.log('ngoai' + this.state.count);
  };

  handleChange = (event: ChangeEvent) => {
    var text = (event.target as HTMLInputElement)?.value;

    this.setState(() => ({
      text,
    }));
  };

  render() {
    const phones = ['iphone', 'samsung', 'oppo'];
    const names = ['Anh', 'Binh', 'Chung'];

    return (
      <div>
        <Dropdown lists={phones}>
          <span>Choose your phone</span>
        </Dropdown>

        <Dropdown lists={names}>
          <span>Choose your name</span>
        </Dropdown>

        <button onClick={this.handleClick}>Click</button>
        <h1>Count: {this.state.count}</h1>

        <input type="text" onChange={this.handleChange}></input>
        <p>{this.state.text}</p>
      </div>
    );
  }
}

export default App;
