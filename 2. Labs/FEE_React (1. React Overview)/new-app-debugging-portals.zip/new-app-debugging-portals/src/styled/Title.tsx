import styled from 'styled-components';

export const Title = styled.h1`
  color: red;
  font-size: 40px;
  background-color: orange;
`;
